<?php $__env->startSection('content'); ?>
    <section
        style="
        background-image: url('<?php echo e(asset('assets/img/backgouund2.jpg')); ?>');
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    height: 120vh;
    ">
        <div class="list-game-client">
            <ul style="
            padding: 0px;
        background-image: url('<?php echo e(asset('assets/img/bakground6.jpg')); ?>');
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    "
                class="list-game">
                <i class="fa-solid fa-backward p-1 fs-5" style="color: aqua; cursor: pointer;" onclick="goBack()"></i>
                <h1 style="margin: 10px 0;color: rgb(255, 109, 4);"><?php echo e($lobby->name); ?></h1>
                <ul class="container-game">
                    <?php if($games->isEmpty()): ?>
                        <h3 style="color: white;">Không game nào trong dữ liệu!</h3>
                    <?php else: ?>
                        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('client.get-score', $game->id)); ?>">
                                <li class="game-item">
                                    <div class="top-game-item">
                                        <div class="game-info">
                                            <img src="<?php echo e(asset('storage/' . $game->image)); ?>" alt="">
                                            <h5><?php echo e($game->title); ?></h5>
                                        </div>
                                        <div
                                        style="display: flex; align-items: center; justify-content: center; position: relative; width: 103px; height: 95px; background-image: url('<?php echo e(asset('assets/img/loadrmbg.png')); ?>'); background-position: center center; background-repeat: no-repeat; background-size: cover;">
                                        <img style="animation: spin 1s linear infinite; position: absolute; width: 100px; height: 84px;"
                                            src="<?php echo e(asset('assets/img/photo_6190289574807322784_x-removebg-preview.png')); ?>" alt="">
                                        <p class="position-absolute"
                                            style="color: yellow; text-align: center; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                                        </p>
                                    </div>
                                    </div>
                                    <div class="bottom-game-item">
                                        <img src="<?php echo e(asset('assets/img/slot_item_bg.png')); ?>" alt="">
                                        <div class="process-bar">
                                        </div>
                                    </div>
                                </li>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </ul>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/client/webdetail.blade.php ENDPATH**/ ?>