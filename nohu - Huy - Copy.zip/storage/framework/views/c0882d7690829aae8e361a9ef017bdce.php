<div>
    <h1>min = <?php echo e($min); ?></h1>
</div>
<?php /**PATH D:\Project\Nổ Hủ\nohu\resources\views/livewire/clients/game/handle-game.blade.php ENDPATH**/ ?>