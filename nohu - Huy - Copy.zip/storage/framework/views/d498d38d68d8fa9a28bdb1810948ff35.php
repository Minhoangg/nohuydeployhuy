<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Quản lý người dùng</h3>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" style="display: flex; justify-content: space-between">
                            <h4 class="card-title">Danh sách người dùng</h4>
                            <a href="<?php echo e(route('system.user-create')); ?>" class="btn btn-success">Thêm Người Dùng</a>
                        </div>
                        <div class="card-body">
                            <!-- Hiển thị thông báo thành công nếu có -->
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>STT</th>
                                            <th>Username</th>
                                            <?php if(auth()->user()->role == 1): ?> <!-- Kiểm tra role của người dùng hiện tại -->
                                                <th>Số điện thoại</th>
                                            <?php endif; ?>
                                            <th>Xu</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($user->name); ?></td>
                                                
                                                <!-- Hiển thị Số điện thoại nếu role của người dùng là 1 -->
                                                <?php if(auth()->user()->role == 1): ?>
                                                    <td><?php echo e($user->phone_number); ?></td>
                                                <?php endif; ?>
                                                
                                                <td><?php echo e($user->coin); ?></td>
                                                <td class="d-flex justify-content-between">
                                                    <form action="<?php echo e(route('system.user-add-coin', $user->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="number" name="coin" class="form-control" placeholder="Nhập xu" min="1" required style="width: 100px; display: inline-block;" />
                                                        <button type="submit" class="btn btn-warning" style="display: inline-block;">Thêm Xu</button>
                                                    </form>
                                                    
                                                    <a href="<?php echo e(route('system.user-delete', $user->id)); ?>" class="btn btn-danger"
                                                        onclick="event.preventDefault(); 
                                                        if (confirm('Bạn có chắc chắn muốn xóa người dùng này?')) {
                                                            document.getElementById('delete-form-<?php echo e($user->id); ?>').submit();
                                                        }">
                                                        Xóa
                                                    </a>

                                                    <!-- Form ẩn để gửi yêu cầu DELETE -->
                                                    <form id="delete-form-<?php echo e($user->id); ?>" action="<?php echo e(route('system.user-delete', $user->id)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/admin/user/userList.blade.php ENDPATH**/ ?>