<div>
    <h1>livewire nè</h1>

    <h4><?php echo e($count); ?></h4>
    <button wire:click="decrement">trừ</button>
    <button wire:click="increment">cộng</button>
</div>
<?php /**PATH D:\Project\DECODE\manageDecode\resources\views/livewire/counter.blade.php ENDPATH**/ ?>