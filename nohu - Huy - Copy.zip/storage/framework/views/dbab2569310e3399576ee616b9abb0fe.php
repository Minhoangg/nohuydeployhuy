<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nổ Hủ</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/scss/client/style.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body>
    <section>
        <?php if (isset($component)) { $__componentOriginal5ca147c0cb876728bd1b8a50dafe2250 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ca147c0cb876728bd1b8a50dafe2250 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header_client','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header_client'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ca147c0cb876728bd1b8a50dafe2250)): ?>
<?php $attributes = $__attributesOriginal5ca147c0cb876728bd1b8a50dafe2250; ?>
<?php unset($__attributesOriginal5ca147c0cb876728bd1b8a50dafe2250); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ca147c0cb876728bd1b8a50dafe2250)): ?>
<?php $component = $__componentOriginal5ca147c0cb876728bd1b8a50dafe2250; ?>
<?php unset($__componentOriginal5ca147c0cb876728bd1b8a50dafe2250); ?>
<?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </section>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script>
        function goBack() {
            window.history.back();
        }
    </script>
</body>

</html><?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/layouts/client/master-layout.blade.php ENDPATH**/ ?>