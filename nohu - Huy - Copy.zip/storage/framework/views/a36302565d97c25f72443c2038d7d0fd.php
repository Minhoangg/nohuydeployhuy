<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h3 class="fw-bold mb-3">Quản lý game</h3>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" style="display: flex; justify-content: space-between">
                            <h4 class="card-title">Danh sách game</h4>
                            <a href="<?php echo e(route('system.game-create')); ?>" class="btn btn-success">Thêm game</a>
                        </div>
                        <div class="card-body">
                            <!-- Hiển thị thông báo thành công nếu có -->
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table id="basic-datatables" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>STT</th>
                                            <th>Tên Game</th>
                                            <th>Lobby</th>
                                            <th>Ảnh</th>
                                            <th>Min Percent</th>
                                            <th>Max Percent</th>
                                            <th>Min Ratio</th>
                                            <th>Max Ratio</th>
                                            <th>Hành động</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($game->title); ?></td>
                                                <td><?php echo e($game->lobby->name); ?></td> <!-- Assuming 'lobby' has a name field -->
                                                <td><img src="<?php echo e(asset('storage/' . $game->image)); ?>" width="50" height="50" alt="<?php echo e($game->title); ?>"></td>
                                                <td><?php echo e($game->min_percent); ?>%</td>
                                                <td><?php echo e($game->max_percent); ?>%</td>
                                                <td><?php echo e($game->min_ratio); ?></td>
                                                <td><?php echo e($game->max_ratio); ?></td>
                                                <td class="d-flex justify-content-between">
                                                    <a href="<?php echo e(route('system.game-edit', $game->id)); ?>" class="btn btn-primary">Sửa</a>
                                                    <a href="<?php echo e(route('system.game-delete', $game->id)); ?>" class="btn btn-danger"
                                                       onclick="event.preventDefault(); 
                                                       if (confirm('Bạn có chắc chắn muốn xóa game này?')) {
                                                           document.getElementById('delete-form-<?php echo e($game->id); ?>').submit();
                                                       }">
                                                       Xóa
                                                    </a>

                                                    <!-- Form ẩn để gửi yêu cầu DELETE -->
                                                    <form id="delete-form-<?php echo e($game->id); ?>" 
                                                          action="<?php echo e(route('system.game-delete', $game->id)); ?>" 
                                                          method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/admin/game/gameList.blade.php ENDPATH**/ ?>