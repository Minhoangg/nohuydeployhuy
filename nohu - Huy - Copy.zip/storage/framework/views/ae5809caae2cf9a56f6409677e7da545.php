<?php $__env->startSection('content'); ?>
    <section
        style="
        background-image: url('<?php echo e(asset('assets/img/photo_6183962405080515886_y.jpg')); ?>');
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    height: 100vh;
    ">
        <div class="core-game-client">

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('handle-game', ['id' => $GameId]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3543399005-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/client/getscoregame.blade.php ENDPATH**/ ?>