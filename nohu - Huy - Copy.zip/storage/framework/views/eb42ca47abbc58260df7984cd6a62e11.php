<?php $__env->startSection('content'); ?>
<div style="padding: 100px">
    <h1>Thêm sảnh game</h1>
    <form action="<?php echo e(route('system.lobby-update', $lobby->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Tên sảnh:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($lobby->name); ?>" required>

            <!-- Hiển thị lỗi cho trường 'name' với chữ đỏ -->
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="image">Ảnh:</label>
            <input type="file" class="form-control" id="image" name="image" required>
            <img src="<?php echo e(asset('storage/' . $lobby->image)); ?>" width="300px" alt="<?php echo e($lobby->title); ?>">

            <!-- Hiển thị lỗi cho trường 'image' với chữ đỏ -->
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary">Lưu</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/admin/lobby/edit.blade.php ENDPATH**/ ?>