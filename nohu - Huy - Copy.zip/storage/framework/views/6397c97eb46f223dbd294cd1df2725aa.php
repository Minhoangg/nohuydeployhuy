<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Quản lý sảnh game</h3>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between">
                        <h4 class="card-title">Danh sách sảnh game</h4>
                        <a href="<?php echo e(route('system.lobby-create')); ?>" class="btn btn-success">Thêm Sảnh game</a>
                    </div>
                    <div class="card-body">
                        <!-- Hiển thị thông báo thành công nếu có -->
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>

                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Tên sảnh</th>
                                        <th>Hình ảnh</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $lobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($lobby->name); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('storage/' . $lobby->image)); ?>" width="50" height="50" alt="<?php echo e($lobby->title); ?>">
                                        </td>
                                        <td class="d-flex justify-content-center gap-2">
                                            <a class="btn btn-warning" href="<?php echo e(route('system.lobby-edit', $lobby->id)); ?>">Sửa</a>
                                            <a href=""
                                                class="btn btn-danger"
                                                onclick="event.preventDefault(); 
                                                        if (confirm('Bạn có chắc chắn muốn xóa người dùng này?')) {
                                                            document.getElementById('delete-form-<?php echo e($lobby->id); ?>').submit();
                                                        }">
                                                Xóa
                                            </a>

                                            <!-- Form ẩn để gửi yêu cầu DELETE -->
                                            <form
                                                id="delete-form-<?php echo e($lobby->id); ?>"
                                                action="<?php echo e(route('system.lobby-delete', $lobby->id)); ?>"
                                                method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/admin/lobby/list.blade.php ENDPATH**/ ?>