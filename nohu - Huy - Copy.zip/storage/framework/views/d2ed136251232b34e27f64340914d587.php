
<link rel="icon" href="<?php echo e(asset('assets/img/kaiadmin/favicon.ico')); ?>" type="image/x-icon" />
<script src="<?php echo e(asset('assets/js/plugin/webfont/webfont.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/kaiadmin.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/fonts.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>" />


<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh">
    <div class="page-inner" style="width: 60%; max-width: 600px;">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <form method="post" action="<?php echo e(route('system.login-submit')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="card-header">
                            <div class="card-title">Đăng nhập quản trị</div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label for="username">Tên đăng nhập :</label>
                                        <input type="text" class="form-control" name="username"
                                            value="<?php echo e(old('username')); ?>" placeholder="Nhập tên đăng nhập">
                                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Mật khẩu</label>
                                        <input type="password" class="form-control" name="password"
                                            value="<?php echo e(old('password')); ?>" placeholder="Nhập mật khẩu">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($errors->has('login')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('login')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="card-action d-flex justify-content-center">
                                <button type="submit" class="btn btn-success">Đăng nhập</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/admin/login.blade.php ENDPATH**/ ?>