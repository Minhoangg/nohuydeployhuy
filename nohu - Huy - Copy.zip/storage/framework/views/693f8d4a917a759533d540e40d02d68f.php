<?php $__env->startSection('content'); ?>
<section style="
        background-image: url('<?php echo e(asset('assets/img/1527c243-151a-4266-b9ed-949b8f091476.jpg')); ?>');
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    ">
    <div class="list-web-client">
        <div style="
        background-image: url('<?php echo e(asset('assets/img/bakground6.jpg')); ?>');
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    " class="container-list-web">
            <h1 style="overflow: hidden; color: rgb(255, 109, 4);">NETSLOT</h1>
            <ul class="menu-web">
                <?php if($lobbys->isEmpty()): ?>
                <h3 style="color: white;">Không có sảnh game nào trong dữ liệu!</h3>
                <?php else: ?>
                <?php $__currentLoopData = $lobbys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-web-client">
                    <a href="<?php echo e(route('client.list-game', $lobby->id)); ?>">
                        <img src="<?php echo e(asset('storage/' . $lobby->image)); ?>" alt="">
                        <p><?php echo e($lobby->name); ?></p>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Nổ Hủ\nohu - Huy\resources\views/client/home.blade.php ENDPATH**/ ?>